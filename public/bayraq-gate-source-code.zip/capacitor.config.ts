const config = {
  appId: 'com.bairaq.gate6',
  appName: 'بوابة بيرق - Bayraq Gate',
  webDir: 'dist',
  server: {
    url: 'https://bairaq-iq.com',
    androidScheme: 'https',
    cleartext: true,
    allowNavigation: [
      'bairaq-iq.com',
      '*.bairaq-iq.com',
      'api.bairaq-iq.com'
    ]
  },
  plugins: {
    LiveUpdates: {
      appId: '54ca6aa9',
      channel: 'production',
      autoUpdateMethod: 'background',
      maxVersions: 2
    },
    CapacitorHttp: {
      enabled: false
    },
    GoogleAuth: {
      scopes: ['profile', 'email'],
      serverClientId: '728585268376-hf25klmd55cjomn0cuhso6qno10gn977.apps.googleusercontent.com',
      forceCodeForRefreshToken: true
    },
    SplashScreen: {
      launchShowDuration: 0,
      launchAutoHide: true,
      backgroundColor: '#020617',
      showSpinner: false,
      androidSplashResourceName: 'splash',
      androidScaleType: 'CENTER_CROP',
      splashFullScreen: true,
      splashImmersive: true
    }
  },
  android: {
    allowMixedContent: true,
    backgroundColor: '#020617'
  }
};

export default config;
